package enumeration;

public enum Race {
	Pu,fg,re
}
