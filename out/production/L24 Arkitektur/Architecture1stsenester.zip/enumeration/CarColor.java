package enumeration;

 public enum CarColor {
	RED, BLACK, BLUE, SILVER

}
