package enumeration;

public enum CarType {
	PORSCHE, FERRARI, JAGUAR
}
