package enumeration;

public class SportsCarDemo {

	
	public static void main(String[] args) {
		SportsCar newCar = new SportsCar(CarType.FERRARI, CarColor.RED,5000000);
		System.out.println(newCar);

	}

}
