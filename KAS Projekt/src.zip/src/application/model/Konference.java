package application.model;

import storage.Storage;

import java.time.LocalDate;
import java.util.ArrayList;

import static java.time.temporal.ChronoUnit.DAYS;

public class Konference {
    private static ArrayList<Tilmelding> tilmeldinger = new ArrayList<>();
    private static ArrayList<Udflugt> udflugter = new ArrayList<>();
    private static ArrayList<Hotel> hoteller = new ArrayList<>();
    private LocalDate start, slut;
    private String lokation, navn;
    private int antalDeltagere, pris;

    public Konference(LocalDate start, LocalDate slut, String lokation, String navn, int pris) {
        this.start = start;
        this.slut = slut;
        this.lokation = lokation;
        this.navn = navn;
        this.pris = pris;
    }

    public static void addHotel(Hotel hotel) {
        if (!hoteller.contains(hotel)) {
            hoteller.add(hotel);
        }
    }

    public static void addUdflugt(Udflugt udflugt) {
        if (!udflugter.contains(udflugt)) {
            udflugter.add(udflugt);
        }
    }

    public static ArrayList<Tilmelding> getTilmeldinger() {
        return tilmeldinger;
    }

    public static ArrayList<Udflugt> getUdflugter() {
        return new ArrayList<>(udflugter);
    }

    public static ArrayList<Hotel> getHoteller() {
        return hoteller;
    }

    public static void addTilmelding(Tilmelding tilmelding) {
        tilmeldinger.add(tilmelding);
    }

    public static Tilmelding createTilmelding(int nummer, LocalDate ankomst, LocalDate afrejse,
                                              Deltager deltager) {
        Tilmelding tilmelding = new Tilmelding(nummer, ankomst, afrejse, deltager);
        tilmeldinger.add(tilmelding);
        Storage.addTilmelding(tilmelding);
        return tilmelding;
    }

    public Udflugt createUdflugt(String navn, String tidspunkt, String mødested, int pris) {
        Udflugt udflugt = new Udflugt(navn, tidspunkt, mødested, pris);
        udflugter.add(udflugt);
        return udflugt;
    }

    public Hotel createHotel(String name, String phone, int pricePerDay) {
        Hotel hotel = new Hotel(name, phone, pricePerDay);
        hoteller.add(hotel);
        return hotel;
    }

    public void removeUdflugt(Udflugt udflugt) {
        if (udflugter.contains(udflugt)) {
            udflugter.remove(udflugt);
        }
    }

    public LocalDate getStart() {
        return start;
    }

    public LocalDate getSlut() {
        return slut;
    }

    public String getLokation() {
        return lokation;
    }

    public String getNavn() {
        return navn;
    }

    public int getPris() {
        return pris;
    }

    public int getAntalDeltagere() {
        return antalDeltagere;
    }

    @Override
    public String toString() {
        return "Navn: " + navn +
                "\nStart: " + start +
                "\nSlut: " + slut +
                "\nLokation: " + lokation +
                "\nPris: " + pris + "\n";
    }

    public int beregnPris(Tilmelding tilmelding) {
        int konferenceDage = (int) DAYS.between(this.getStart(), this.getSlut()) + 1;
        System.out.println("Antal dage for konference " + konferenceDage);
        int hotelNætter = (int) DAYS.between(tilmelding.getAnkomst(), tilmelding.getAfrejse());
        System.out.println("Antal nætter på hotel " + hotelNætter);
        int konferencePris = this.pris * konferenceDage;
        System.out.println("Konference " + konferencePris);
        int hotelPris = tilmelding.getHotel().getPrisPerDag() * hotelNætter;
        System.out.println(tilmelding.getHotel().getPrisPerDag());
        System.out.println("Hotelpris " + hotelPris);
        int udflugtPris = 0;
        for (Udflugt u : tilmelding.getUdflugter()) {
            udflugtPris += u.getPris();
            System.out.println("Foreløbig: " + udflugtPris);
        }
        int tilkøbPris = tilmelding.getHotel().createTilkøb("Wifi", 50).getPris();
        if (tilmelding.getDeltager().isFirma() == true) {
            hotelPris = 0;
            udflugtPris = 0;
            konferencePris = 0;
        }
        if (tilmelding.getDeltager().getRolle() == Rolle.FOREDRAGSHOLDER) {
            konferencePris = 0;
        }
        if (tilmelding.getDeltager().isHasLedsager() == false) {
            udflugtPris = 0;
        }
        int samletPris = konferencePris + hotelPris + udflugtPris + tilkøbPris;

        return samletPris;
    }
}
