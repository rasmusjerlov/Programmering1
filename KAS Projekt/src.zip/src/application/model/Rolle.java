package application.model;

public enum Rolle {
    FOREDRAGSHOLDER, FIRMADELTAGER, PRIVAT;

}
