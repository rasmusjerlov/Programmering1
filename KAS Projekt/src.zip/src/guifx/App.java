package guifx;

import application.model.*;
import javafx.application.Application;
import storage.Storage;

import java.time.LocalDate;

public class App {
    public static void main(String[] args) {
        Deltager d1 = new Deltager("Rasmus", "128321", "Dansk", false, false, Rolle.PRIVAT);
        Hotel h1 = new Hotel("Dangleterre", "213123123", 1500);
        Konference konference = new Konference(LocalDate.of(2023, 8, 4),
                LocalDate.of(2023, 8, 6), "Din mor", "Fuck dig", 1500);
        Udflugt udflugt = new Udflugt("Byrundtur", "I morgen", "Din mor", 250);
        Tilmelding tilmelding = new Tilmelding(1, LocalDate.of(2023, 8, 3),
                LocalDate.of(2023, 8, 9), d1);
        Konference.addTilmelding(tilmelding);
        Konference.addHotel(h1);
        Konference.addUdflugt(udflugt);
        Storage.addKonference(konference);
        Application.launch(GUI.class);
    }
}
